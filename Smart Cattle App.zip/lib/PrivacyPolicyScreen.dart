import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text("privacy_policy".tr),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Text(
            '''
${'pp_intro'.tr}

${'pp_data_collected'.tr}
${'pp_data_items'.tr}

${'pp_how_use'.tr}
${'pp_use_items'.tr}

${'pp_never_share'.tr}

${'pp_consent'.tr}

${'pp_contact'.tr}
''',
            style: TextStyle(fontSize: 16, color: Colors.green.shade900),
          ),
        ),
      ),
    );
  }
}
