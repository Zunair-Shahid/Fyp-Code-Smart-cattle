import 'package:flutter/material.dart';
import 'package:get/get.dart';

class TermsConditionsScreen extends StatelessWidget {
  const TermsConditionsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text("terms_conditions".tr),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Text(
            '''
${'tc_intro'.tr}

${'tc_point1'.tr}
${'tc_point2'.tr}
${'tc_point3'.tr}
${'tc_point4'.tr}
${'tc_point5'.tr}

${'tc_contact'.tr}
''',
            style: TextStyle(fontSize: 16, color: Colors.green.shade900),
          ),
        ),
      ),
    );
  }
}
