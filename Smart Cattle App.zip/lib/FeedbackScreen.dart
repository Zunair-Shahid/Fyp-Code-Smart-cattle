import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FeedbackScreen extends StatelessWidget {
  const FeedbackScreen({Key? key}) : super(key: key);

  Future<String?> _getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('userId');
  }

  Future<void> _submitFeedback(BuildContext context, String feedbackText) async {
    if (feedbackText.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("feedback_empty".tr)),
      );
      return;
    }

    final userId = await _getUserId();

    if (userId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("feedback_not_logged_in".tr)),
      );
      return;
    }

    final dbRef = FirebaseDatabase.instance.ref().child("feedback").child(userId);

    final newFeedbackRef = dbRef.push();
    await newFeedbackRef.set({
      "text": feedbackText.trim(),
      "created_at": DateTime.now().toIso8601String(),
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("feedback_thank_you".tr)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final _controller = TextEditingController();

    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text("feedback".tr),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              "feedback_intro".tr,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 12),
            TextField(
              controller: _controller,
              maxLines: 5,
              decoration: InputDecoration(
                hintText: "feedback_hint".tr,
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 12),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green.shade700,
              ),
              onPressed: () async {
                await _submitFeedback(context, _controller.text);
                _controller.clear();
              },
              icon: Icon(Icons.send),
              label: Text("feedback_submit".tr),
            )
          ],
        ),
      ),
    );
  }
}
