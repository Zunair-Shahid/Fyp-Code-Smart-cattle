import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen();

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();

  final _usernameController = TextEditingController();
  final _emailController = TextEditingController();

  bool _loading = false;
  Map<String, dynamic>? userData;

  @override
  void initState() {
    super.initState();
    _fetchUserData();
  }

  void _fetchUserData() async {
    setState(() {
      _loading = true;
    });

    final prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString('userId');

    final dbRef =
        FirebaseDatabase.instance.ref().child('users/${userId}');
    final snapshot = await dbRef.get();

    if (snapshot.exists) {
      setState(() {
        userData = Map<String, dynamic>.from(snapshot.value as Map);
        _usernameController.text = userData!['username'] ?? '';
        _emailController.text = userData!['email'] ?? '';
      });
    }

    setState(() {
      _loading = false;
    });
  }

  void _saveChanges() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _loading = true;
    });

    final prefs = await SharedPreferences.getInstance();
  String? userId = prefs.getString('userId');

    final dbRef =
        FirebaseDatabase.instance.ref().child('users/${userId}');

    await dbRef.update({
      'username': _usernameController.text.trim(),
      'email': _emailController.text.trim(),
      'updated_at': DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now()),
    });

    setState(() {
      _loading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Profile updated successfully!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text('My Profile'),
      ),
      body: _loading
          ? Center(child: CircularProgressIndicator())
          : userData == null
              ? Center(child: Text('User data not found'))
              : Padding(
                  padding: EdgeInsets.all(16),
                  child: Form(
                    key: _formKey,
                    child: ListView(
                      children: [
                        Center(
                          child: CircleAvatar(
                            radius: 40,
                            backgroundColor: Colors.green.shade200,
                            child: Icon(
                              Icons.person,
                              size: 40,
                              color: Colors.green.shade700,
                            ),
                          ),
                        ),
                        SizedBox(height: 20),
                        TextFormField(
                          initialValue: userData!['userid'],
                          enabled: false,
                          decoration: InputDecoration(
                            labelText: 'User ID',
                            filled: true,
                            fillColor: Colors.green.shade100,
                            border: OutlineInputBorder(),
                          ),
                        ),
                        SizedBox(height: 12),
                        TextFormField(
                          controller: _usernameController,
                          decoration: InputDecoration(
                            labelText: 'Username',
                            prefixIcon: Icon(Icons.person,
                                color: Colors.green.shade700),
                            filled: true,
                            fillColor: Colors.green.shade100,
                            border: OutlineInputBorder(),
                          ),
                          validator: (value) =>
                              value!.isEmpty ? 'Enter Username' : null,
                        ),
                        SizedBox(height: 12),
                        TextFormField(
                          controller: _emailController,
                          decoration: InputDecoration(
                            labelText: 'Email',
                            prefixIcon:
                                Icon(Icons.email, color: Colors.green.shade700),
                            filled: true,
                            fillColor: Colors.green.shade100,
                            border: OutlineInputBorder(),
                          ),
                          validator: (value) =>
                              value!.isEmpty ? 'Enter Email' : null,
                        ),
                        SizedBox(height: 12),
                        TextFormField(
                          initialValue: userData!['role'],
                          enabled: false,
                          decoration: InputDecoration(
                            labelText: 'Role',
                            filled: true,
                            fillColor: Colors.green.shade100,
                            border: OutlineInputBorder(),
                          ),
                        ),
                        SizedBox(height: 12),
                        TextFormField(
                          initialValue: userData!['created_at'],
                          enabled: false,
                          decoration: InputDecoration(
                            labelText: 'Created At',
                            filled: true,
                            fillColor: Colors.green.shade100,
                            border: OutlineInputBorder(),
                          ),
                        ),
                        SizedBox(height: 20),
                        _loading
                            ? Center(child: CircularProgressIndicator())
                            : ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green.shade700,
                                  padding: EdgeInsets.symmetric(vertical: 14),
                                ),
                                icon: Icon(Icons.save),
                                label: Text(
                                  'Save Changes',
                                  style: TextStyle(fontSize: 16),
                                ),
                                onPressed: _saveChanges,
                              ),
                      ],
                    ),
                  ),
                ),
    );
  }
}
