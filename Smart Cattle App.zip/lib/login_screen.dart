import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:get/get.dart';
import 'register_screen.dart';
import 'package:fyp/dashboard_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _loading = false;
  bool _obscurePassword = true;

  void _login() async {
    setState(() {
      _loading = true;
    });

    final dbRef = FirebaseDatabase.instance.ref().child("users");

    final snapshot = await dbRef.once();
    bool found = false;

    String? loggedUserId;
    String? loggedUsername;
    String? loggedEmail;

    if (snapshot.snapshot.exists) {
      final data = snapshot.snapshot.value as Map;

      data.forEach((key, value) {
        if (value["email"] == _emailController.text.trim() &&
            value["password"] == _passwordController.text.trim()) {
          found = true;
          loggedUserId = key;
          loggedUsername = value["username"];
          loggedEmail = value["email"];
        }
      });
    }

    setState(() {
      _loading = false;
    });

    if (found && loggedUserId != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('userId', loggedUserId!);
      await prefs.setString('username', loggedUsername!);
      await prefs.setString('email', loggedEmail!);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("login_success".tr)),
      );

      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => DashboardScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("invalid_credentials".tr)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text("login_screen_title".tr),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            SizedBox(height: 20),
            Center(
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.green.shade100,
                ),
                padding: EdgeInsets.all(16),
                child: Icon(
                  Icons.pets,
                  size: 60,
                  color: Colors.green.shade700,
                ),
              ),
            ),
            SizedBox(height: 20),
            Center(
              child: Text(
                'login_screen_welcome'.tr,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade800,
                ),
              ),
            ),
            SizedBox(height: 30),
            TextFormField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: "email".tr,
                prefixIcon: Icon(Icons.email, color: Colors.green.shade700),
                filled: true,
                fillColor: Colors.green.shade100,
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextFormField(
              controller: _passwordController,
              obscureText: _obscurePassword,
              decoration: InputDecoration(
                labelText: "password".tr,
                prefixIcon: Icon(Icons.lock, color: Colors.green.shade700),
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscurePassword ? Icons.visibility_off : Icons.visibility,
                    color: Colors.green.shade700,
                  ),
                  onPressed: () {
                    setState(() {
                      _obscurePassword = !_obscurePassword;
                    });
                  },
                ),
                filled: true,
                fillColor: Colors.green.shade100,
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            _loading
                ? Center(child: CircularProgressIndicator())
                : ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade700,
                      padding: EdgeInsets.symmetric(vertical: 14),
                    ),
                    icon: Icon(Icons.login),
                    onPressed: _login,
                    label: Text(
                      "login_button".tr,
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
            TextButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => RegisterScreen()),
                );
              },
              child: Text("dont_have_account".tr),
            ),
          ],
        ),
      ),
    );
  }
}
