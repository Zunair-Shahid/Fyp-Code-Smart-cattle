import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'cattle_list_screen.dart';
import 'package:fyp/dashboard_screen.dart';

class LanguageSelectorScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text('select_language'.tr),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            SizedBox(height: 40),
            Center(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.green.shade100,
                  shape: BoxShape.circle,
                ),
                padding: EdgeInsets.all(24),
                child: Icon(
                  Icons.language,
                  size: 60,
                  color: Colors.green.shade700,
                ),
              ),
            ),
            SizedBox(height: 24),
            Text(
              'choose_language_prompt'.tr,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.green.shade800,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 40),
            _languageCard(
              context,
              icon: Icons.flag,
              title: 'english'.tr,
              locale: Locale('en', 'US'),
            ),
            SizedBox(height: 16),
            _languageCard(
              context,
              icon: Icons.language,
              title: 'urdu'.tr,
              locale: Locale('ur', 'PK'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _languageCard(BuildContext context, {
    required IconData icon,
    required String title,
    required Locale locale,
  }) {
    return InkWell(
      onTap: () {
        Get.updateLocale(locale);
        Get.offAll(() => DashboardScreen());
      },
      borderRadius: BorderRadius.circular(12),
      child: Card(
        elevation: 3,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          child: Row(
            children: [
              Icon(icon, size: 28, color: Colors.green.shade700),
              SizedBox(width: 16),
              Text(
                title,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.green.shade900,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Spacer(),
              Icon(Icons.arrow_forward_ios, size: 20, color: Colors.green.shade400),
            ],
          ),
        ),
      ),
    );
  }
}
