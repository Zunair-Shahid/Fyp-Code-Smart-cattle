import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ContactUsScreen extends StatelessWidget {
  const ContactUsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text("contact_us_title".tr),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "contact_us_intro".tr,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.green.shade800,
              ),
            ),
            SizedBox(height: 16),
            Text(
              "contact_us_email".tr,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              "contact_us_phone".tr,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              "contact_us_whatsapp".tr,
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
