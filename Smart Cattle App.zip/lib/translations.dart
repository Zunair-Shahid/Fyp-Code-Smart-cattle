import 'package:get/get.dart';

class AppTranslations extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
        'en_US': {
          // Existing translations
          'cattle_list': 'Cattle List',
          'data': 'Data',
          'loading': 'Loading...',
          'select_language': 'Select Language',
          'english': 'English',
          'urdu': 'Urdu',
          'settings': 'Settings',
          'change_language': 'Change Language',
          'home': 'Home',
          'logout': 'Logout',
          'logged_out': 'Logged out',

          // SettingsScreen translations
          'my_profile': 'My Profile',
          'user_not_logged_in': 'User not logged in',
          'about_app': 'About the App',
          'privacy_policy': 'Privacy Policy',
          'terms_conditions': 'Terms & Conditions',
          'contact_us': 'Contact Us',
          'help_faq': 'Help & FAQ',
          'farm_tips': 'Farm Tips',
          'feedback': 'Feedback',
          'app_version': 'App Version',

          // CattleListScreen translations
          'add_new_cow': 'Add New Cow',
          'breed': 'Breed',
          'age': 'Age',
          'age_months': 'Age (months)',
          'weight': 'Weight',
          'weight_kg': 'Weight (kg)',
          'cancel': 'Cancel',
          'save': 'Save',
          'no_cattle_records': 'No cattle records found.',
          'not_available': 'N/A',

          'tc_intro': 'By using this app, you agree to the following terms:',
          'tc_point1':
              '1. You are responsible for the accuracy of the data you enter.',
          'tc_point2': '2. This app is provided "as is" without warranty.',
          'tc_point3':
              '3. We are not liable for any damages arising from using this app.',
          'tc_point4':
              '4. You agree not to misuse or attempt to hack this application.',
          'tc_point5': '5. We may update these terms at any time.',
          'tc_contact': 'For questions, contact support@yourcompany.com.',

          'pp_intro':
              'We respect your privacy. This app collects only necessary data to provide core functionalities, such as user authentication and cattle management.',
          'pp_data_collected': 'Data Collected:',
          'pp_data_items':
              '• Email, username, and user ID for login.\n• Cattle data you enter (for your personal use).',
          'pp_how_use': 'How We Use Data:',
          'pp_use_items':
              '• To authenticate and identify users.\n• To store your cattle-related information.\n• To improve app features.',
          'pp_never_share': 'We never share your data with third parties.',
          'pp_consent': 'By using this app, you consent to this policy.',
          'pp_contact':
              'For any questions, please contact support@yourcompany.com.',

          // FAQ Questions
          'faq_q_add_cow': 'How do I add a new cow?',
          'faq_q_update_profile': 'How do I update my profile?',
          'faq_q_data_storage': 'How is my data stored?',
          'faq_q_data_visibility': 'Who can see my data?',
          'faq_q_delete_cow': 'How do I delete a cow record?',
          'faq_q_change_language': 'Can I change the app language?',
          'faq_q_reset_password': 'How do I reset my password?',
          'faq_q_feedback': 'How do I give feedback?',
          'faq_q_backup': 'Is my data backed up?',
          'faq_q_export': 'Can I export my cattle data?',
          'faq_q_update_app': 'How do I update the app?',
          'faq_q_contact_support': 'How can I contact support?',

          // FAQ Answers
          'faq_a_add_cow':
              'Tap the + button on the Cattle List screen and fill in the details.',
          'faq_a_update_profile':
              'Go to Settings > My Profile to update your information.',
          'faq_a_data_storage':
              'All your data is securely saved in Firebase Realtime Database.',
          'faq_a_data_visibility':
              'Only you and authorized app administrators have access.',
          'faq_a_delete_cow':
              'Open the cow\'s details and tap the delete icon to remove it.',
          'faq_a_change_language':
              'Yes. Go to Settings > Change Language and select your preferred language.',
          'faq_a_reset_password':
              'Currently, password reset requires contacting support.',
          'faq_a_feedback':
              'Go to Settings > Feedback and submit your comments.',
          'faq_a_backup':
              'Yes, your data is stored securely in the cloud and backed up automatically.',
          'faq_a_export': 'Data export is coming soon in future updates.',
          'faq_a_update_app':
              'Visit the app store and install the latest version when updates are available.',
          'faq_a_contact_support':
              'Go to Settings > Contact Us to reach out via email or phone.',

          'feedback_intro':
              'We value your feedback. Please let us know how we can improve.',
          'feedback_hint': 'Enter your feedback here...',
          'feedback_submit': 'Submit',
          'feedback_empty': 'Please enter your feedback.',
          'feedback_not_logged_in': 'User not logged in.',
          'feedback_thank_you': 'Thank you for your feedback!',

          'farm_tips_title': 'Farm Management Tips',

          'farm_tip_feed_quality_title': 'Feed Quality',
          'farm_tip_feed_quality_desc':
              'Provide high-quality fodder and clean water to improve milk production.',

          'farm_tip_health_monitoring_title': 'Health Monitoring',
          'farm_tip_health_monitoring_desc':
              'Check cattle health daily and vaccinate regularly.',

          'farm_tip_record_keeping_title': 'Record Keeping',
          'farm_tip_record_keeping_desc':
              'Use this app to track cow details, health history, and breeding.',

          'farm_tip_clean_environment_title': 'Clean Environment',
          'farm_tip_clean_environment_desc':
              'Keep barns clean and dry to prevent diseases.',

          'farm_tip_regular_deworming_title': 'Regular Deworming',
          'farm_tip_regular_deworming_desc':
              'Deworm cattle every 3–6 months to maintain health.',

          'farm_tip_breeding_management_title': 'Breeding Management',
          'farm_tip_breeding_management_desc':
              'Record breeding dates and monitor pregnant cows closely.',

          'farm_tip_proper_housing_title': 'Proper Housing',
          'farm_tip_proper_housing_desc':
              'Provide shelter with good ventilation and protection from weather.',

          'farm_tip_observation_title': 'Observation',
          'farm_tip_observation_desc':
              'Observe cattle behavior for signs of illness or stress.',

          'farm_tip_milking_title': 'Proper Milking Practices',
          'farm_tip_milking_desc':
              'Wash udders before milking and keep equipment clean.',

          'farm_tip_calf_care_title': 'Calf Care',
          'farm_tip_calf_care_desc':
              'Feed colostrum to newborn calves within 2 hours of birth.',

              'contact_us_title': 'Contact Us',
  'contact_us_intro': 'Need help or have questions?',
  'contact_us_email': 'Email: zunair.shahid09@gmail.com',
  'contact_us_phone': 'Phone: +92 333 3343604',
  'contact_us_whatsapp': 'WhatsApp: +92 333 3343604',

  'app_version_title': 'App Version',
  'app_version_number': 'Version 1.0.0',
  'app_version_desc': 'Initial release of Smart Cattle Monitoring.',
  'app_version_whats_new': "What's New",
  'app_version_feature_1': '- Cattle list and detail screens',
  'app_version_feature_2': '- Profile and settings',
  'app_version_feature_3': '- Multi-language support',
  'app_version_feature_4': '- Cattle management tips',

  'about_app_title': 'About the App',
  'about_app_name': 'Smart Cattle Monitoring',
  'about_app_description': 'This app empowers farmers to monitor their cattle with ease and efficiency. Track cow health, manage profiles, and get real-time updates for a smarter farm.',
  'about_app_version': 'Version: 1.0.0',
  'about_app_developer': 'Developed by SCM Devs',

  "register_screen_title": "Register Cattle Account",
  "register_screen_heading": "Create Your Farm Account",
  "username": "Username",
  "email": "Email",
  "password": "Password",
  "enter_username": "Enter Username",
  "enter_email": "Enter Email",
  "enter_password": "Enter Password",
  "register_button": "Register",
  "already_have_account": "Already have an account? Login",
  "register_success": "User registered successfully!",

  "login_screen_title": "Cattle Farm Login",
  "login_screen_welcome": "Welcome Back, Farmer!",
  "login_button": "Login",
  "dont_have_account": "Don't have an account? Register",
  "login_success": "Login successful!",
  "invalid_credentials": "Invalid credentials",

  'choose_language_prompt': 'Please choose your preferred language:',
          'no_coordinates': 'No valid coordinates to show on map.',

          'health_status': 'Health Status',
  'pulse': 'Pulse',
  'temperature': 'Temperature',
  'latitude': 'Latitude',
  'longitude': 'Longitude',
  'accel_x': 'Acceleration X',
  'accel_y': 'Acceleration Y',
  'accel_z': 'Acceleration Z',
  'No_valid_coordinates_to_show_on_map.': 'No valid coordinates to show on the map.',

  // Cattle List Screen
  'Add New Cow': 'Add New Cow',
  'Breed': 'Breed',
  'Age (months)': 'Age (months)',
  'Weight (kg)': 'Weight (kg)',
  'Cancel': 'Cancel',
  'Save': 'Save',
  'No cattle records found.': 'No cattle records found.',
  'Cow Name': 'Cow Name',
  'Enter cow name.': 'Enter cow name.',
  'Name already exists.': 'Name already exists.',

  'Cattle Dashboard': 'Cattle Dashboard',
  'Total Cows': 'Total Cows',
  'Top 3 Heaviest Cows': 'Top 3 Heaviest Cows',
  'Weight Distribution': 'Weight Distribution',
  'No data': 'No data',
  'kg': 'kg',
        },
        'ur_PK': {
          // Existing translations
          'cattle_list': 'مویشیوں کی فہرست',
          'data': 'تفصیلات',
          'loading': 'لوڈ ہو رہا ہے...',
          'select_language': 'زبان منتخب کریں',
          'english': 'انگریزی',
          'urdu': 'اردو',
          'settings': 'ترتیبات',
          'change_language': 'زبان تبدیل کریں',
          'home': 'ہوم',
          'logout': 'لاگ آؤٹ',
          'logged_out': 'آپ لاگ آؤٹ ہوگئے',

          // SettingsScreen translations
          'my_profile': 'میری پروفائل',
          'user_not_logged_in': 'صارف لاگ ان نہیں ہے',
          'about_app': 'ایپ کے بارے میں',
          'privacy_policy': 'رازداری کی پالیسی',
          'terms_conditions': 'شرائط و ضوابط',
          'contact_us': 'ہم سے رابطہ کریں',
          'help_faq': 'مدد اور سوالات',
          'farm_tips': 'فارم کے مشورے',
          'feedback': 'آراء',
          'app_version': 'ایپ ورژن',

          // CattleListScreen translations
          'add_new_cow': 'نئی گائے شامل کریں',
          'breed': 'نسل',
          'age': 'عمر',
          'age_months': 'عمر (مہینے)',
          'weight': 'وزن',
          'weight_kg': 'وزن (کلوگرام)',
          'cancel': 'منسوخ کریں',
          'save': 'محفوظ کریں',
          'no_cattle_records': 'کوئی مویشیوں کا ریکارڈ نہیں ملا۔',
          'not_available': 'دستیاب نہیں',

          'tc_intro':
              'اس ایپ کے استعمال سے، آپ مندرجہ ذیل شرائط سے اتفاق کرتے ہیں:',
          'tc_point1': '1. آپ داخل کردہ ڈیٹا کی درستگی کے ذمہ دار ہیں۔',
          'tc_point2':
              '2. یہ ایپ "جوں کی توں" بغیر کسی ضمانت کے فراہم کی جاتی ہے۔',
          'tc_point3':
              '3. اس ایپ کے استعمال سے پیدا ہونے والے کسی بھی نقصان کی ہم ذمہ داری نہیں لیتے۔',
          'tc_point4':
              '4. آپ اس ایپ کو غلط استعمال یا ہیک کرنے کی کوشش نہیں کریں گے۔',
          'tc_point5': '5. ہم کسی بھی وقت ان شرائط کو تبدیل کر سکتے ہیں۔',
          'tc_contact': 'سوالات کے لیے، support@yourcompany.com پر رابطہ کریں۔',

          'pp_intro':
              'ہم آپ کی رازداری کا احترام کرتے ہیں۔ یہ ایپ صرف ضروری ڈیٹا جمع کرتی ہے تاکہ بنیادی خصوصیات فراہم کی جا سکیں، جیسے صارف کی توثیق اور مویشیوں کا انتظام۔',
          'pp_data_collected': 'جمع شدہ ڈیٹا:',
          'pp_data_items':
              '• لاگ ان کے لیے ای میل، صارف نام، اور صارف شناختی نمبر۔\n• آپ کی ذاتی مویشیوں کی معلومات۔',
          'pp_how_use': 'ڈیٹا کا استعمال:',
          'pp_use_items':
              '• صارفین کی شناخت اور توثیق کے لیے۔\n• آپ کی مویشیوں کی معلومات کو محفوظ کرنے کے لیے۔\n• ایپ کی خصوصیات کو بہتر بنانے کے لیے۔',
          'pp_never_share':
              'ہم آپ کا ڈیٹا کبھی تیسرے فریق کے ساتھ شیئر نہیں کرتے۔',
          'pp_consent':
              'اس ایپ کو استعمال کرکے، آپ اس پالیسی سے اتفاق کرتے ہیں۔',
          'pp_contact':
              'کسی بھی سوال کے لیے، support@yourcompany.com پر رابطہ کریں۔',

          // FAQ Questions
          'faq_q_add_cow': 'میں نئی گائے کیسے شامل کروں؟',
          'faq_q_update_profile': 'میں اپنی پروفائل کیسے اپ ڈیٹ کروں؟',
          'faq_q_data_storage': 'میرا ڈیٹا کہاں محفوظ ہوتا ہے؟',
          'faq_q_data_visibility': 'میرا ڈیٹا کون دیکھ سکتا ہے؟',
          'faq_q_delete_cow': 'میں گائے کا ریکارڈ کیسے حذف کروں؟',
          'faq_q_change_language': 'کیا میں ایپ کی زبان تبدیل کر سکتا ہوں؟',
          'faq_q_reset_password': 'میں پاس ورڈ کیسے ری سیٹ کروں؟',
          'faq_q_feedback': 'میں رائے کیسے دوں؟',
          'faq_q_backup': 'کیا میرا ڈیٹا بیک اپ ہوتا ہے؟',
          'faq_q_export': 'کیا میں اپنا ڈیٹا ایکسپورٹ کر سکتا ہوں؟',
          'faq_q_update_app': 'میں ایپ کیسے اپ ڈیٹ کروں؟',
          'faq_q_contact_support': 'میں سپورٹ سے کیسے رابطہ کروں؟',

          // FAQ Answers
          'faq_a_add_cow':
              'Cattle List اسکرین پر + بٹن دبائیں اور تفصیلات درج کریں۔',
          'faq_a_update_profile':
              'Settings > My Profile میں جا کر اپنی معلومات اپ ڈیٹ کریں۔',
          'faq_a_data_storage':
              'آپ کا تمام ڈیٹا محفوظ طریقے سے Firebase Realtime Database میں محفوظ کیا جاتا ہے۔',
          'faq_a_data_visibility':
              'صرف آپ اور مجاز ایڈمنسٹریٹر ہی ڈیٹا دیکھ سکتے ہیں۔',
          'faq_a_delete_cow':
              'گائے کی تفصیلات کھولیں اور حذف کرنے کے آئیکن پر ٹیپ کریں۔',
          'faq_a_change_language':
              'جی ہاں۔ Settings > Change Language میں جا کر زبان منتخب کریں۔',
          'faq_a_reset_password':
              'پاس ورڈ ری سیٹ کرنے کے لیے سپورٹ سے رابطہ کرنا ہوگا۔',
          'faq_a_feedback': 'Settings > Feedback میں جا کر اپنی رائے دیں۔',
          'faq_a_backup':
              'جی ہاں، آپ کا ڈیٹا کلاؤڈ میں محفوظ اور خودکار بیک اپ ہوتا ہے۔',
          'faq_a_export': 'ڈیٹا ایکسپورٹ جلد ہی دستیاب ہوگا۔',
          'faq_a_update_app': 'ایپ اسٹور پر جا کر تازہ ترین ورژن انسٹال کریں۔',
          'faq_a_contact_support':
              'Settings > Contact Us میں جا کر ای میل یا فون کے ذریعے رابطہ کریں۔',

          'feedback_intro':
              'ہم آپ کی رائے کی قدر کرتے ہیں۔ براہ کرم ہمیں بتائیں کہ ہم کیسے بہتری لا سکتے ہیں۔',
          'feedback_hint': 'اپنی رائے یہاں درج کریں...',
          'feedback_submit': 'جمع کریں',
          'feedback_empty': 'براہ کرم اپنی رائے درج کریں۔',
          'feedback_not_logged_in': 'صارف لاگ ان نہیں ہے۔',
          'feedback_thank_you': 'آپ کی رائے کا شکریہ!',

          'farm_tips_title': 'فارم مینجمنٹ کے نکات',

          'farm_tip_feed_quality_title': 'معیاری خوراک',
          'farm_tip_feed_quality_desc':
              'دودھ کی پیداوار بڑھانے کے لیے معیاری چارہ اور صاف پانی فراہم کریں۔',

          'farm_tip_health_monitoring_title': 'صحت کی نگرانی',
          'farm_tip_health_monitoring_desc':
              'روزانہ صحت چیک کریں اور باقاعدگی سے ویکسین لگائیں۔',

          'farm_tip_record_keeping_title': 'ریکارڈ رکھنا',
          'farm_tip_record_keeping_desc':
              'گائے کی تفصیلات، صحت اور افزائش کا ریکارڈ رکھنے کے لیے ایپ استعمال کریں۔',

          'farm_tip_clean_environment_title': 'صاف ماحول',
          'farm_tip_clean_environment_desc':
              'بیماریوں سے بچنے کے لیے باڑہ صاف اور خشک رکھیں۔',

          'farm_tip_regular_deworming_title': 'باقاعدہ کیڑوں کا علاج',
          'farm_tip_regular_deworming_desc':
              'ہر 3 سے 6 ماہ بعد کیڑوں کا علاج کریں۔',

          'farm_tip_breeding_management_title': 'افزائش کی مینجمنٹ',
          'farm_tip_breeding_management_desc':
              'افزائش کی تاریخ درج کریں اور حاملہ گایوں پر نظر رکھیں۔',

          'farm_tip_proper_housing_title': 'مناسب رہائش',
          'farm_tip_proper_housing_desc':
              'اچھی ہوا دار اور موسمی تحفظ والی رہائش فراہم کریں۔',

          'farm_tip_observation_title': 'مشاہدہ',
          'farm_tip_observation_desc':
              'بیماری یا دباؤ کی علامات کے لیے گایوں کے رویے پر نظر رکھیں۔',

          'farm_tip_milking_title': 'دودھ نکالنے کی درست طریقہ',
          'farm_tip_milking_desc':
              'دودھ نکالنے سے پہلے تھن صاف کریں اور آلات کو صاف رکھیں۔',

          'farm_tip_calf_care_title': 'بچھڑوں کی دیکھ بھال',
          'farm_tip_calf_care_desc':
              'پیدائش کے 2 گھنٹے کے اندر بچھڑے کو کولسٹرم پلائیں۔',

              'contact_us_title': 'ہم سے رابطہ کریں',
  'contact_us_intro': 'مدد چاہیے یا سوال ہیں؟',
  'contact_us_email': 'ای میل: zunair.shahid09@gmail.com',
  'contact_us_phone': 'فون: +92 333 3343604',
  'contact_us_whatsapp': 'واٹس ایپ: +92 333 3343604',

  'app_version_title': 'ایپ ورژن',
  'app_version_number': 'ورژن 1.0.0',
  'app_version_desc': 'سمارٹ کیٹل مانیٹرنگ کا پہلا اجرا۔',
  'app_version_whats_new': 'نیا کیا ہے',
  'app_version_feature_1': '- مویشیوں کی فہرست اور تفصیل اسکرینیں',
  'app_version_feature_2': '- پروفائل اور ترتیبات',
  'app_version_feature_3': '- کثیر لسانی سہولت',
  'app_version_feature_4': '- مویشیوں کی دیکھ بھال کے نکات',

  'about_app_title': 'ایپ کے بارے میں',
  'about_app_name': 'سمارٹ کیٹل مانیٹرنگ',
  'about_app_description': 'یہ ایپ کسانوں کو آسانی اور مؤثر طریقے سے مویشیوں کی نگرانی کرنے میں مدد دیتی ہے۔ گائے کی صحت کو ٹریک کریں، پروفائلز منظم کریں اور اسمارٹ فارم کے لیے ریئل ٹائم اپڈیٹس حاصل کریں۔',
  'about_app_version': 'ورژن: 1.0.0',
  'about_app_developer': 'ڈویلپر: SCM ڈیوپس',

  "register_screen_title": "اکاؤنٹ رجسٹر کریں",
  "register_screen_heading": "اپنا فارم اکاؤنٹ بنائیں",
  "username": "صارف نام",
  "email": "ای میل",
  "password": "پاس ورڈ",
  "enter_username": "صارف نام درج کریں",
  "enter_email": "ای میل درج کریں",
  "enter_password": "پاس ورڈ درج کریں",
  "register_button": "رجسٹر کریں",
  "already_have_account": "پہلے سے اکاؤنٹ ہے؟ لاگ ان کریں",
  "register_success": "صارف کامیابی سے رجسٹر ہوگیا!",

  "login_screen_title": "مویشی فارم لاگ ان",
  "login_screen_welcome": "خوش آمدید کسان!",
  "login_button": "لاگ ان کریں",
  "dont_have_account": "اکاؤنٹ نہیں ہے؟ رجسٹر کریں",
  "login_success": "کامیابی سے لاگ ان ہوگیا!",
  "invalid_credentials": "غلط معلومات",

  'choose_language_prompt': 'اپنی پسندیدہ زبان منتخب کریں:',
          'no_coordinates': 'نقشے پر دکھانے کے لیے درست کوآرڈینیٹس موجود نہیں ہیں۔',

          'health_status': 'صحت کی حالت',
  'pulse': 'نبض',
  'temperature': 'درجہ حرارت',
  'latitude': 'عرض البلد',
  'longitude': 'طول البلد',
  'accel_x': 'ایکس محور کی رفتار',
  'accel_y': 'وائی محور کی رفتار',
  'accel_z': 'زیڈ محور کی رفتار',
  'No_valid_coordinates_to_show_on_map.': 'نقشے پر دکھانے کے لئے درست کوآرڈینیٹس موجود نہیں ہیں۔',

  // Cattle List Screen
  'Add New Cow': 'نیا جانور شامل کریں',
  'Breed': 'نسل',
  'Age (months)': 'عمر (مہینے)',
  'Weight (kg)': 'وزن (کلوگرام)',
  'Cancel': 'منسوخ کریں',
  'Save': 'محفوظ کریں',
  'No cattle records found.': 'کوئی جانور کا ریکارڈ نہیں ملا۔',
  'Cow Name': 'جانور کا نام',
  'Enter cow name.': 'جانور کا نام درج کریں۔',
  'Name already exists.': 'یہ نام پہلے سے موجود ہے۔',

  'Cattle Dashboard': 'مویشیوں کا ڈیش بورڈ',
  'Total Cows': 'کل مویشی',
  'Top 3 Heaviest Cows': 'سب سے وزنی ۳ مویشی',
  'Weight Distribution': 'وزن کی تقسیم',
  'No data': 'کوئی ڈیٹا نہیں',
  'kg': 'کلوگرام',
        },
      };
}
