import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HelpFaqScreen extends StatelessWidget {
  const HelpFaqScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text("help_faq".tr),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            _faqItem("faq_q_add_cow".tr, "faq_a_add_cow".tr),
            _faqItem("faq_q_update_profile".tr, "faq_a_update_profile".tr),
            _faqItem("faq_q_data_storage".tr, "faq_a_data_storage".tr),
            _faqItem("faq_q_data_visibility".tr, "faq_a_data_visibility".tr),
            _faqItem("faq_q_delete_cow".tr, "faq_a_delete_cow".tr),
            _faqItem("faq_q_change_language".tr, "faq_a_change_language".tr),
            _faqItem("faq_q_reset_password".tr, "faq_a_reset_password".tr),
            _faqItem("faq_q_feedback".tr, "faq_a_feedback".tr),
            _faqItem("faq_q_backup".tr, "faq_a_backup".tr),
            _faqItem("faq_q_export".tr, "faq_a_export".tr),
            _faqItem("faq_q_update_app".tr, "faq_a_update_app".tr),
            _faqItem("faq_q_contact_support".tr, "faq_a_contact_support".tr),
          ],
        ),
      ),
    );
  }

  Widget _faqItem(String question, String answer) {
    return ExpansionTile(
      title: Text(
        question,
        style: TextStyle(color: Colors.green.shade800, fontWeight: FontWeight.bold),
      ),
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(answer),
        )
      ],
    );
  }
}
