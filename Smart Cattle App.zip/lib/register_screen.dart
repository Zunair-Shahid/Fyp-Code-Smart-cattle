import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:intl/intl.dart';
import 'package:get/get.dart';
import 'login_screen.dart';

class RegisterScreen extends StatefulWidget {
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _loading = false;
  bool _obscurePassword = true;

  void _register() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _loading = true;
    });

    final dbRef = FirebaseDatabase.instance.ref().child("users");
    final now = DateFormat('yyyy-MM-dd HH:mm:ss').format(DateTime.now());

    // Generate a unique ID
    final newUserRef = dbRef.push();
    final userId = newUserRef.key;

    await newUserRef.set({
      "userid": userId,
      "username": _usernameController.text.trim(),
      "email": _emailController.text.trim(),
      "password": _passwordController.text.trim(),
      "role": "user",
      "created_at": now,
      "updated_at": now,
    });

    setState(() {
      _loading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("register_success".tr)),
    );

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text("register_screen_title".tr),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              SizedBox(height: 20),
              Center(
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.green.shade100,
                  ),
                  padding: EdgeInsets.all(16),
                  child: Icon(
                    Icons.pets,
                    size: 60,
                    color: Colors.green.shade700,
                  ),
                ),
              ),
              SizedBox(height: 20),
              Center(
                child: Text(
                  'register_screen_heading'.tr,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.green.shade800,
                  ),
                ),
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _usernameController,
                decoration: InputDecoration(
                  labelText: "username".tr,
                  prefixIcon: Icon(Icons.person, color: Colors.green.shade700),
                  filled: true,
                  fillColor: Colors.green.shade100,
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "enter_username".tr : null,
              ),
              SizedBox(height: 12),
              TextFormField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: "email".tr,
                  prefixIcon: Icon(Icons.email, color: Colors.green.shade700),
                  filled: true,
                  fillColor: Colors.green.shade100,
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "enter_email".tr : null,
              ),
              SizedBox(height: 12),
              TextFormField(
                controller: _passwordController,
                obscureText: _obscurePassword,
                decoration: InputDecoration(
                  labelText: "password".tr,
                  prefixIcon: Icon(Icons.lock, color: Colors.green.shade700),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscurePassword ? Icons.visibility_off : Icons.visibility,
                      color: Colors.green.shade700,
                    ),
                    onPressed: () {
                      setState(() {
                        _obscurePassword = !_obscurePassword;
                      });
                    },
                  ),
                  filled: true,
                  fillColor: Colors.green.shade100,
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "enter_password".tr : null,
              ),
              SizedBox(height: 20),
              _loading
                  ? Center(child: CircularProgressIndicator())
                  : ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green.shade700,
                        padding: EdgeInsets.symmetric(vertical: 14),
                      ),
                      icon: Icon(Icons.app_registration),
                      onPressed: _register,
                      label: Text(
                        "register_button".tr,
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
              TextButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => LoginScreen()),
                  );
                },
                child: Text("already_have_account".tr),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
