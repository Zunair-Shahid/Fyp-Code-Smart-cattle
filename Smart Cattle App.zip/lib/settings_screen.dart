import 'package:flutter/material.dart';
import 'package:fyp/AboutAppScreen.dart';
import 'package:fyp/AppVersionScreen.dart';
import 'package:fyp/ContactUsScreen.dart';
import 'package:fyp/FarmTipsScreen.dart';
import 'package:fyp/FeedbackScreen.dart';
import 'package:fyp/HelpFaqScreen.dart';
import 'package:fyp/PrivacyPolicyScreen.dart';
import 'package:fyp/ProfileScreen.dart';
import 'package:fyp/TermsConditionsScreen.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'language_selector_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  Future<String?> _getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('userId');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text('Settings'.tr),
      ),
      body: ListView(
        children: [
          ListTile(
            leading: Icon(Icons.person, color: Colors.green.shade700),
            title: Text('my_profile'.tr),
            trailing:
                Icon(Icons.arrow_forward_ios, color: Colors.green.shade700),
            onTap: () async {
              final userId = await _getUserId();
              if (userId != null) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ProfileScreen(),
                  ),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('user_not_logged_in'.tr)),
                );
              }
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.language, color: Colors.green.shade700),
            title: Text('change_language'.tr),
            trailing:
                Icon(Icons.arrow_forward_ios, color: Colors.green.shade700),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => LanguageSelectorScreen(),
                ),
              );
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.info, color: Colors.green.shade700),
            title: Text('about_app'.tr),
            trailing:
                Icon(Icons.arrow_forward_ios, color: Colors.green.shade700),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AboutAppScreen(),
                ),
              );
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.privacy_tip, color: Colors.green.shade700),
            title: Text('privacy_policy'.tr),
            trailing:
                Icon(Icons.arrow_forward_ios, color: Colors.green.shade700),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PrivacyPolicyScreen(),
                ),
              );
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.article, color: Colors.green.shade700),
            title: Text('terms_conditions'.tr),
            trailing:
                Icon(Icons.arrow_forward_ios, color: Colors.green.shade700),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => TermsConditionsScreen(),
                ),
              );
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.contact_mail, color: Colors.green.shade700),
            title: Text('contact_us'.tr),
            trailing:
                Icon(Icons.arrow_forward_ios, color: Colors.green.shade700),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ContactUsScreen(),
                ),
              );
            },
          ),
          Divider(),
          ListTile(
  leading: Icon(Icons.help, color: Colors.green.shade700),
  title: Text('help_faq'.tr),
  trailing: Icon(Icons.arrow_forward_ios, color: Colors.green.shade700),
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => HelpFaqScreen(),
      ),
    );
  },
),
Divider(),
ListTile(
  leading: Icon(Icons.lightbulb, color: Colors.green.shade700),
  title: Text('farm_tips'.tr),
  trailing: Icon(Icons.arrow_forward_ios, color: Colors.green.shade700),
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FarmTipsScreen(),
      ),
    );
  },
),
Divider(),
ListTile(
  leading: Icon(Icons.feedback, color: Colors.green.shade700),
  title: Text('feedback'.tr),
  trailing: Icon(Icons.arrow_forward_ios, color: Colors.green.shade700),
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FeedbackScreen(),
      ),
    );
  },
),
Divider(),
ListTile(
  leading: Icon(Icons.info_outline, color: Colors.green.shade700),
  title: Text('app_version'.tr),
  trailing: Icon(Icons.arrow_forward_ios, color: Colors.green.shade700),
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AppVersionScreen(),
      ),
    );
  },
),

        ],
      ),
    );
  }
}
