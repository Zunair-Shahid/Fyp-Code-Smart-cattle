import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AppVersionScreen extends StatelessWidget {
  const AppVersionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text("app_version_title".tr),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            ListTile(
              leading: Icon(Icons.info, color: Colors.green.shade700),
              title: Text("app_version_number".tr),
              subtitle: Text("app_version_desc".tr),
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.update, color: Colors.green.shade700),
              title: Text("app_version_whats_new".tr),
              subtitle: Text(
                [
                  "app_version_feature_1".tr,
                  "app_version_feature_2".tr,
                  "app_version_feature_3".tr,
                  "app_version_feature_4".tr,
                ].join("\n"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
