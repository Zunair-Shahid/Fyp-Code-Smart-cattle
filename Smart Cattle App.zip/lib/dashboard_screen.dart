import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:fyp/cattle_list_screen.dart';
import 'package:fyp/settings_screen.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'cattle_detail_screen.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late DatabaseReference _cattleRef;
  Map<String, dynamic>? cattleMap;

  @override
  void initState() {
    super.initState();
    _cattleRef = FirebaseDatabase.instance.ref('cattle');
    _cattleRef.onValue.listen((DatabaseEvent event) {
      final data = event.snapshot.value as Map?;
      if (data != null) {
        setState(() {
          cattleMap = Map<String, dynamic>.from(data);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final totalCows = cattleMap?.length ?? 0;

    List<MapEntry<String, dynamic>> sortedCows = [];

    if (cattleMap != null) {
      sortedCows = cattleMap!.entries.toList();
      sortedCows.sort((a, b) {
        final wa = double.tryParse(a.value["weight"] ?? "0") ?? 0;
        final wb = double.tryParse(b.value["weight"] ?? "0") ?? 0;
        return wb.compareTo(wa);
      });
    }

    final top3 = sortedCows.take(3).toList();

    return Scaffold(
      backgroundColor: Colors.green.shade50,
      drawer: Drawer(
        child: Column(
          children: [
            UserAccountsDrawerHeader(
              decoration: BoxDecoration(color: Colors.green.shade700),
              accountName: FutureBuilder<String?>(
                future: SharedPreferences.getInstance()
                    .then((prefs) => prefs.getString('username')),
                builder: (context, snapshot) {
                  return Text(snapshot.data ?? ''.tr);
                },
              ),
              accountEmail: FutureBuilder<String?>(
                future: SharedPreferences.getInstance()
                    .then((prefs) => prefs.getString('email')),
                builder: (context, snapshot) {
                  return Text(snapshot.data ?? ''.tr);
                },
              ),
              currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(Icons.person, color: Colors.green),
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'.tr),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Settings'.tr),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SettingsScreen(),
                  ),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('logout'.tr),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Logged out'.tr)),
                );
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text("Cattle Dashboard".tr),
      ),
      body: cattleMap == null
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  // Summary Card
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => CattleListScreen()),
                      );
                    },
                    child: Card(
                      color: Colors.green.shade100,
                      child: ListTile(
                        leading: Icon(Icons.pets,
                            color: Colors.green.shade800, size: 40),
                        title: Text(
                          "Total Cows".tr,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.green.shade800,
                          ),
                        ),
                        trailing: Text(
                          "$totalCows",
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.green.shade900,
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 16),
                  // Top 3 Heaviest Cows
                  Card(
                    color: Colors.green.shade100,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          ListTile(
                            leading: Icon(Icons.leaderboard,
                                color: Colors.green.shade800),
                            title: Text(
                              "Top 3 Heaviest Cows".tr,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.green.shade800,
                              ),
                            ),
                          ),
                          ...top3.map((entry) {
                            final weight = entry.value["weight"] ?? "N/A";
                            final breed = entry.value["breed"] ?? "Unknown";
                            return ListTile(
                              title: Text(
                                "${entry.key}",
                                style: TextStyle(color: Colors.green.shade900),
                              ),
                              subtitle: Text("${'Breed'.tr}: $breed"),
                              trailing: Text(
                                "$weight ${'kg'.tr}",
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                            );
                          }),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 16),
                  // Weight Bar Chart
                  Card(
                    color: Colors.green.shade100,
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Weight Distribution".tr,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.green.shade800,
                            ),
                          ),
                          SizedBox(
                              height: 200, child: _buildBarChart(sortedCows)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildBarChart(List<MapEntry<String, dynamic>> cows) {
    if (cows.isEmpty) {
      return Center(child: Text("No data".tr));
    }

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        barTouchData: BarTouchData(enabled: true),
        titlesData: FlTitlesData(
          leftTitles: AxisTitles(
            sideTitles: SideTitles(showTitles: true),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                final index = value.toInt();
                if (index < cows.length) {
                  return Text(
                    cows[index].key.substring(0, 3).toUpperCase(),
                    style: TextStyle(fontSize: 10),
                  );
                }
                return Text('');
              },
            ),
          ),
          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        borderData: FlBorderData(show: false),
        barGroups: cows
            .asMap()
            .entries
            .map(
              (entry) => BarChartGroupData(
                x: entry.key,
                barRods: [
                  BarChartRodData(
                    toY: double.tryParse(entry.value.value["weight"] ?? "0") ??
                        0,
                    color: Colors.green.shade700,
                    width: 12,
                  ),
                ],
              ),
            )
            .toList(),
      ),
    );
  }
}
