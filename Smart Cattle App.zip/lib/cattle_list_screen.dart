// import 'package:flutter/material.dart';
// import 'package:firebase_database/firebase_database.dart';
// import 'package:fyp/settings_screen.dart';
// import 'package:get/get.dart';
// import 'cattle_detail_screen.dart';

// class CattleListScreen extends StatefulWidget {
//   @override
//   _CattleListScreenState createState() => _CattleListScreenState();
// }

// class _CattleListScreenState extends State<CattleListScreen> {
//   late DatabaseReference _cattleRef;
//   Map<String, dynamic>? cattleMap;

//   @override
//   void initState() {
//     super.initState();
//     _cattleRef = FirebaseDatabase.instance.ref('cattle'.tr);

//     // Listen to /cattle/
//     _cattleRef.onValue.listen((DatabaseEvent event) {
//       final data = event.snapshot.value as Map?;
//       if (data != null) {
//         setState(() {
//           cattleMap = Map<String, dynamic>.from(data);
//         });
//       }
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text('cattle_list'.tr)),
//       drawer: Drawer(
//         child: Column(
//           children: [
//             UserAccountsDrawerHeader(
//               accountName: Text('Username Here'.tr),
//               accountEmail: null,
//               currentAccountPicture: CircleAvatar(
//                 backgroundImage: AssetImage('assets/profile_placeholder.png'.tr),
//               ),
//             ),
//             ListTile(
//               leading: Icon(Icons.home),
//               title: Text('home'.tr),
//               onTap: () {
//                 Navigator.pop(context);
//               },
//             ),
//             ListTile(
//               leading: Icon(Icons.settings),
//               title: Text('settings'.tr),
//               onTap: () {
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (_) => SettingsScreen(),
//                   ),
//                 );
//               },
//             ),
//             ListTile(
//               leading: Icon(Icons.logout),
//               title: Text('logout'.tr),
//               onTap: () {
//                 Navigator.pop(context);
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(content: Text('logged_out'.tr)),
//                 );
//               },
//             ),
//           ],
//         ),
//       ),
//       body: cattleMap == null
//           ? Center(child: Text('loading'.tr))
//           : ListView(
//               children: cattleMap!.entries.map((entry) {
//                 final cowId = entry.key;
//                 return Card(
//                   margin: EdgeInsets.all(8),
//                   child: ListTile(
//                     title: Text(cowId.toUpperCase()),
//                     trailing: Icon(Icons.arrow_forward),
//                     onTap: () {
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                           builder: (_) => CattleDetailScreen(cowId: cowId),
//                         ),
//                       );
//                     },
//                   ),
//                 );
//               }).toList(),
//             ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:fyp/settings_screen.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'cattle_detail_screen.dart';

class CattleListScreen extends StatefulWidget {
  @override
  _CattleListScreenState createState() => _CattleListScreenState();
}

class _CattleListScreenState extends State<CattleListScreen> {
  late DatabaseReference _cattleRef;
  Map<String, dynamic>? cattleMap;

  @override
  void initState() {
    super.initState();
    _cattleRef = FirebaseDatabase.instance.ref('cattle'.tr);

    // Listen to /cattle/
    _cattleRef.onValue.listen((DatabaseEvent event) {
      final data = event.snapshot.value as Map?;
      if (data != null) {
        setState(() {
          cattleMap = Map<String, dynamic>.from(data);
        });
      } else {
        setState(() {
          cattleMap = {};
        });
      }
    });
  }

  void _showAddCowDialog() {
    final nameController = TextEditingController();
    final breedController = TextEditingController();
    final ageController = TextEditingController();
    final weightController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Add New Cow'.tr),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: 'Cow Name'.tr),
              ),
              TextField(
                controller: breedController,
                decoration: InputDecoration(labelText: 'Breed'.tr),
              ),
              TextField(
                controller: ageController,
                decoration: InputDecoration(labelText: 'Age (months)'.tr),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: weightController,
                decoration: InputDecoration(labelText: 'Weight (kg)'.tr),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            child: Text('Cancel'.tr),
            onPressed: () => Navigator.pop(context),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green.shade700,
            ),
            child: Text('Save'.tr),
            onPressed: () async {
              final name = nameController.text.trim();
              if (name.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Enter cow name.'.tr)),
                );
                return;
              }

              final existingNames = cattleMap?.values
                  .map((e) => (e as Map)['name']?.toString().toLowerCase())
                  .where((n) => n != null)
                  .toList();

              if (existingNames != null &&
                  existingNames.contains(name.toLowerCase())) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Name already exists.'.tr)),
                );
                return;
              }

              final newCowRef = _cattleRef.push();
              await newCowRef.set({
                'name': name,
                'breed': breedController.text.trim(),
                'age': ageController.text.trim(),
                'weight': weightController.text.trim(),
                'created_at': DateTime.now().toIso8601String(),
              });
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text('Cattle List'.tr),
      ),
      body: cattleMap == null
          ? Center(child: CircularProgressIndicator())
          : cattleMap!.isEmpty
              ? Center(child: Text('No cattle records found.'.tr))
              : ListView(
                  children: cattleMap!.entries.map((entry) {
                    final cowId = entry.key;
                    final cowData = Map<String, dynamic>.from(entry.value);
                    return Card(
                      margin: EdgeInsets.all(8),
                      child: ListTile(
                        title: Text(cowData['name'] != null
                            ? cowData['name']
                            : cowId.toUpperCase()),
                        subtitle: Text(
                            '${'Breed'.tr}: ${cowData['breed'] ?? 'N/A'}\n'
                            '${'Age (months)'.tr}: ${cowData['age'] ?? 'N/A'}\n'
                            '${'Weight (kg)'.tr}: ${cowData['weight'] ?? 'N/A'}'),
                        trailing: Icon(Icons.arrow_forward),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => CattleDetailScreen(cowId: cowId),
                            ),
                          );
                        },
                      ),
                    );
                  }).toList(),
                ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green.shade700,
        child: Icon(Icons.add),
        onPressed: _showAddCowDialog,
      ),
    );
  }
}
