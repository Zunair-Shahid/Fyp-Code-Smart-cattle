import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:get/get.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';

class CattleDetailScreen extends StatefulWidget {
  final String cowId;

  const CattleDetailScreen({required this.cowId});

  @override
  _CattleDetailScreenState createState() => _CattleDetailScreenState();
}

class _CattleDetailScreenState extends State<CattleDetailScreen> {
  late DatabaseReference _cowRef;
  Map<String, dynamic>? cowData;
  LatLng? userLocation;

  @override
  void initState() {
    super.initState();
    _cowRef = FirebaseDatabase.instance.ref('cattle/${widget.cowId}');

    // Listen to this cow's data
    _cowRef.onValue.listen((DatabaseEvent event) {
      final data = event.snapshot.value as Map?;
      if (data != null) {
        setState(() {
          cowData = Map<String, dynamic>.from(data);
        });
      }
    });

    _getCurrentLocation();
  }

  void _getCurrentLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return;
    }

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);

    setState(() {
      userLocation = LatLng(position.latitude, position.longitude);
    });
  }

  @override
  Widget build(BuildContext context) {
    final scmColor = Colors.green.shade700; // SCM Theme Blue

    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        title: Text('${widget.cowId.toUpperCase()} ${'data'.tr}'),
        backgroundColor: Colors.green.shade700,
      ),
      body: cowData == null
          ? Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(scmColor),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(16.0),
              children: [
                _buildCard(
                  icon: Icons.favorite,
                  label: 'health_status'.tr,
                  value: cowData!['HealthStatus'] ?? 'Unknown',
                  color: Colors.green,
                ),
                _buildCard(
                  icon: Icons.monitor_heart,
                  label: 'pulse'.tr,
                  value: cowData!['pulse'].toString(),
                  color: scmColor,
                ),
                _buildCard(
                  icon: Icons.thermostat,
                  label: 'temperature'.tr,
                  value: cowData!['temperature'].toString(),
                  color: scmColor,
                ),
                _buildCard(
                  icon: Icons.place,
                  label: 'latitude'.tr,
                  value: cowData!['latitude'].toString(),
                  color: scmColor,
                ),
                _buildCard(
                  icon: Icons.place,
                  label: 'longitude'.tr,
                  value: cowData!['longitude'].toString(),
                  color: scmColor,
                ),
                _buildCard(
                  icon: Icons.directions_run,
                  label: 'accel_x'.tr,
                  value: cowData!['accelX'].toString(),
                  color: scmColor,
                ),
                _buildCard(
                  icon: Icons.directions_run,
                  label: 'accel_y'.tr,
                  value: cowData!['accelY'].toString(),
                  color: scmColor,
                ),
                _buildCard(
                  icon: Icons.directions_run,
                  label: 'accel_z'.tr,
                  value: cowData!['accelZ'].toString(),
                  color: scmColor,
                ),
                if (cowData != null &&
                    cowData!['latitude'] != null &&
                    cowData!['longitude'] != null)
                  SizedBox(
                    height: 300,
                    child: FlutterMap(
                      options: MapOptions(
                        center: LatLng(
                          double.tryParse(cowData!['latitude'].toString()) ?? 0,
                          double.tryParse(cowData!['longitude'].toString()) ??
                              0,
                        ),
                        zoom: 15,
                      ),
                      children: [
                        TileLayer(
                          urlTemplate:
                              "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                          subdomains: ['a', 'b', 'c'],
                        ),
                        MarkerLayer(
                          markers: [
                            Marker(
                              point: LatLng(
                                double.tryParse(
                                        cowData!['latitude'].toString()) ??
                                    0,
                                double.tryParse(
                                        cowData!['longitude'].toString()) ??
                                    0,
                              ),
                              width: 80,
                              height: 80,
                              rotate: true,
                              child: Icon(
                                Icons.pets,
                                color: Colors.red,
                                size: 40,
                              ),
                            ),
                            if (userLocation != null)
                              Marker(
                                point: userLocation!,
                                width: 80,
                                height: 80,
                                rotate: true,
                                child: Icon(
                                  Icons.person_pin_circle,
                                  color: Colors.green.shade700,
                                  size: 40,
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                  )
                else
                  SizedBox(
                    height: 50,
                    child: Center(
                      child: Text("No_valid_coordinates_to_show_on_map.".tr),
                    ),
                  ),
              ],
            ),
    );
  }

  Widget _buildCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    bool isInvalid = value == '-1' || value == 'null';

    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: Icon(
          icon,
          color: color,
          size: 30,
        ),
        title: Text(
          label,
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        trailing: Text(
          isInvalid ? 'N/A' : value,
          style: TextStyle(
            color: isInvalid ? Colors.red : Colors.black,
            fontSize: 16,
          ),
        ),
      ),
    );
  }
}
