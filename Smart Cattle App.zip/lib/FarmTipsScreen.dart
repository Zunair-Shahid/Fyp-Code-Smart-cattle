import 'package:flutter/material.dart';
import 'package:get/get.dart';

class FarmTipsScreen extends StatelessWidget {
  const FarmTipsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green.shade50,
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        title: Text("farm_tips_title".tr),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            _tipItem("farm_tip_feed_quality_title".tr, "farm_tip_feed_quality_desc".tr),
            _tipItem("farm_tip_health_monitoring_title".tr, "farm_tip_health_monitoring_desc".tr),
            _tipItem("farm_tip_record_keeping_title".tr, "farm_tip_record_keeping_desc".tr),
            _tipItem("farm_tip_clean_environment_title".tr, "farm_tip_clean_environment_desc".tr),
            _tipItem("farm_tip_regular_deworming_title".tr, "farm_tip_regular_deworming_desc".tr),
            _tipItem("farm_tip_breeding_management_title".tr, "farm_tip_breeding_management_desc".tr),
            _tipItem("farm_tip_proper_housing_title".tr, "farm_tip_proper_housing_desc".tr),
            _tipItem("farm_tip_observation_title".tr, "farm_tip_observation_desc".tr),
            _tipItem("farm_tip_milking_title".tr, "farm_tip_milking_desc".tr),
            _tipItem("farm_tip_calf_care_title".tr, "farm_tip_calf_care_desc".tr),
          ],
        ),
      ),
    );
  }

  Widget _tipItem(String title, String description) {
    return Card(
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: Icon(Icons.check_circle_outline, color: Colors.green.shade700),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(description),
      ),
    );
  }
}
